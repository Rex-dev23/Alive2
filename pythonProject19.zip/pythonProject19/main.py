import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QLineEdit, QPushButton, \
    QMessageBox, QTableWidget, QTableWidgetItem, QDialog, QDialogButtonBox, QInputDialog
import pymysql


class AddEditDialog(QDialog):
    def __init__(self, title, fields, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)

        layout = QVBoxLayout()

        self.inputs = {}
        for field in fields:
            label = QLabel(field)
            layout.addWidget(label)
            input_field = QLineEdit()
            input_field.setPlaceholderText(field)
            layout.addWidget(input_field)
            self.inputs[field] = input_field

        if "id" in fields:
            label = QLabel("id")
            layout.addWidget(label)
            input_field = QLineEdit()
            input_field.setPlaceholderText("id")
            layout.addWidget(input_field)
            self.inputs["id"] = input_field

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(self.button_box)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(layout)

    def get_data(self):
        return [input_field.text() for input_field in self.inputs.values()]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("School Management")
        self.setGeometry(100, 100, 800, 600)

        layout = QVBoxLayout()

        self.buttons = {}

        for name, action in [("Show Students", self.show_students),
                             ("Show Teachers", self.show_teachers),
                             ("Show Grades", self.show_grades),
                             ("Add Student", self.add_student),
                             ("Edit Student", self.edit_student),
                             ("Delete Student", self.delete_student),
                             ("Add Teacher", self.add_teacher),
                             ("Edit Teacher", self.edit_teacher),
                             ("Delete Teacher", self.delete_teacher),
                             ("Add Grade", self.add_grade),
                             ("Edit Grade", self.edit_grade),
                             ("Delete Grade", self.delete_grade),
                             ("Grades by Teacher", self.grades_by_teacher),
                             ("Average Grade by Subject", self.average_grade_by_subject),
                             ("Low Grades Students", self.low_grades_students)]:
            button = QPushButton(name)
            button.clicked.connect(action)
            layout.addWidget(button)
            self.buttons[name] = button

        self.result_table = QTableWidget()
        layout.addWidget(self.result_table)

        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        self.db_connection = pymysql.connect(host='localhost', user='root', password='root', database='aliev')
        self.cursor = self.db_connection.cursor()

    def execute_query(self, query, data=None):
        try:
            self.cursor.execute(query, data)
            self.db_connection.commit()
            return True
        except pymysql.Error as e:
            QMessageBox.warning(self, "Error", f"Database error: {e}")
            return False

    def show_table(self, title, headers, query, data=None):
        self.result_table.setRowCount(0)
        self.result_table.setColumnCount(len(headers))
        self.result_table.setHorizontalHeaderLabels(headers)
        self.cursor.execute(query, data)
        rows = self.cursor.fetchall()
        for row_number, row_data in enumerate(rows):
            self.result_table.insertRow(row_number)
            for column_number, data in enumerate(row_data):
                self.result_table.setItem(row_number, column_number, QTableWidgetItem(str(data)))

    def show_students(self):
        headers = ["id", "full_name", "birthdate", "address", "phone", "father_info", "mother_info", "class"]
        query = "SELECT * FROM Students"
        self.show_table("Students", headers, query)

    def show_teachers(self):
        headers = ["id", "subject", "class"]
        query = "SELECT * FROM Teachers"
        self.show_table("Teachers", headers, query)

    def show_grades(self):
        headers = ["id", "student_id", "teacher_id", "date", "grade"]
        query = "SELECT * FROM Grades"
        self.show_table("Grades", headers, query)

    def add_edit_record(self, title, fields, table_name, action="add"):
        dialog = AddEditDialog(title, fields)
        if action == "edit":
            row = self.result_table.currentRow()
            if row == -1:
                QMessageBox.warning(self, "Error", "Please select a record to edit.")
                return
            for index, field in enumerate(fields):
                dialog.inputs[field].setText(self.result_table.item(row, index).text())

        if dialog.exec_() == QDialog.Accepted:
            data = dialog.get_data()
            if action == "add":
                if table_name == "teachers":
                    query = "INSERT INTO Teachers (subject, class) VALUES (%s, %s)"
                else:
                    placeholders = ', '.join(['%s'] * len(fields))
                    query = f"INSERT INTO {table_name} VALUES ({placeholders})"
            else:
                id_field = "id"
                query = f"UPDATE {table_name} SET "
                query += ', '.join([f"{field} = %s" for field in fields])
                query += f" WHERE {id_field} = %s"
                data.append(data[0])  # добавляем id в конец списка
                data = data[1:]  # убираем первый элемент (id)

            if self.execute_query(query, data):
                getattr(self, f"show_{table_name.lower()}s")()

    def add_student(self):
        self.add_edit_record("Add Student",
                             ["full_name", "birthdate", "address", "phone", "father_info", "mother_info", "class"],
                             "students")

    def edit_student(self):
        self.add_edit_record("Edit Student",
                             ["id", "full_name", "birthdate", "address", "phone", "father_info", "mother_info", "class"],
                             "students", "edit")

    def delete_record(self, table_name):
        row = self.result_table.currentRow()
        if row != -1:
            id_field = "id"
            id_value = self.result_table.item(row, 0).text()
            reply = QMessageBox.question(self, f"Delete {table_name}",
                                         f"Are you sure you want to delete this {table_name.lower()}?",
                                         QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                query = f"DELETE FROM {table_name} WHERE {id_field} = %s"
                if self.execute_query(query, (id_value,)):
                    getattr(self, f"show_{table_name.lower()}s")()

    def delete_student(self):
        self.delete_record("students")

    def add_teacher(self):
        self.add_edit_record("Add Teacher", ["subject", "class"], "teachers")

    def edit_teacher(self):
        self.add_edit_record("Edit Teacher", ["id", "subject", "class"], "teachers", "edit")

    def delete_teacher(self):
        self.delete_record("teachers")

    def add_grade(self):
        self.add_edit_record("Add Grade", ["student_id", "teacher_id", "date", "grade"], "grades")

    def edit_grade(self):
        self.add_edit_record("Edit Grade", ["id", "student_id", "teacher_id", "date", "grade"], "grades", "edit")

    def delete_grade(self):
        self.delete_record("grades")

    def grades_by_teacher(self):
        teacher_id, ok = QInputDialog.getInt(self, "Teacher ID", "Enter Teacher ID:")
        if ok:
            query = "SELECT s.full_name, g.grade FROM Grades g JOIN Students s ON g.student_id = s.id WHERE g.teacher_id = %s"
            self.show_table("Grades by Teacher", ["Student Name", "Grade"], query, (teacher_id,))

    def average_grade_by_subject(self):
        subject, ok = QInputDialog.getText(self, "Subject", "Enter Subject:")
        if ok:
            query = "SELECT AVG(g.grade) FROM Grades g JOIN Teachers t ON g.teacher_id = t.id WHERE t.subject = %s"
            self.cursor.execute(query, (subject,))
            average_grade = self.cursor.fetchone()[0]
            QMessageBox.information(self, "Average Grade", f"The average grade for {subject} is {average_grade:.2f}")

    def low_grades_students(self):
        query = "SELECT s.full_name, SUM(g.grade) as total_grade FROM Grades g JOIN Students s ON g.student_id = s.id GROUP BY s.id ORDER BY total_grade LIMIT 3"
        self.show_table("Low Grades Students", ["Student Name", "Total Grade"], query)

    def closeEvent(self, event):
        self.db_connection.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
