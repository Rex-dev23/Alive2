import pymysql

class Database:
    try:
        def __init__(self, host, user, password, database):
            self.connection = pymysql.connect(host=host, user=user, password=password, database=database)
            self.cursor = self.connection.cursor()
            print()
    except:
        print()
